-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 23, 2013 at 03:23 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `scc`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE IF NOT EXISTS `activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `act_name` varchar(30) NOT NULL,
  `act_place` varchar(30) NOT NULL,
  `IsActive` bit(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`id`, `act_name`, `act_place`, `IsActive`) VALUES
(1, 'Horizone1', 'Nirma University', b'1'),
(2, 'Techfest 2013', 'BPCCS, Gandhinagar', b'1'),
(17, 'Lucky Ali on 10th March', 'DA-IICT', b'1'),
(18, 'Bhumi chauhan', 'Ahmedabad', b'1'),
(19, 'gj', 'hfh', b'1');

-- --------------------------------------------------------

--
-- Table structure for table `album`
--

CREATE TABLE IF NOT EXISTS `album` (
  `AlbumId` int(11) NOT NULL AUTO_INCREMENT,
  `AlbumName` varchar(200) NOT NULL,
  `AddUserId` int(11) NOT NULL,
  `AddDate` datetime NOT NULL,
  `EditDate` datetime NOT NULL,
  `StreamId` int(11) NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  PRIMARY KEY (`AlbumId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `album`
--

INSERT INTO `album` (`AlbumId`, `AlbumName`, `AddUserId`, `AddDate`, `EditDate`, `StreamId`, `IsActive`) VALUES
(1, 'SAIT COLLASES 2009', 1, '2012-10-03 21:51:45', '0000-00-00 00:00:00', 34, 1),
(2, 'SAIT 2012', 1, '2012-10-27 12:20:54', '0000-00-00 00:00:00', 34, 1),
(8, '2013', 0, '2013-03-20 14:23:48', '0000-00-00 00:00:00', 34, 1);

-- --------------------------------------------------------

--
-- Table structure for table `discussion`
--

CREATE TABLE IF NOT EXISTS `discussion` (
  `DiscussionId` int(11) NOT NULL AUTO_INCREMENT,
  `DiscussionSubject` varchar(200) NOT NULL,
  `DiscussionDescription` varchar(8000) NOT NULL,
  `AddUserId` int(11) NOT NULL,
  `AddDateTime` int(11) NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  PRIMARY KEY (`DiscussionId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `discussion`
--


-- --------------------------------------------------------

--
-- Table structure for table `discussion_reply`
--

CREATE TABLE IF NOT EXISTS `discussion_reply` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `DiscussionId` int(11) NOT NULL,
  `Description` varchar(8000) NOT NULL,
  `ReplyUserId` int(11) NOT NULL,
  `AddDate` datetime NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `discussion_reply`
--


-- --------------------------------------------------------

--
-- Table structure for table `election`
--

CREATE TABLE IF NOT EXISTS `election` (
  `ElectionId` int(11) NOT NULL AUTO_INCREMENT,
  `ElectionName` varchar(100) NOT NULL,
  `ElectionTypeId` int(11) NOT NULL,
  `StreamId` int(11) NOT NULL,
  `ElectionStartDate` date NOT NULL,
  `ElectionEndDate` datetime NOT NULL,
  `AddUserId` int(11) NOT NULL,
  `AddDate` datetime NOT NULL,
  `EditDate` datetime NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  PRIMARY KEY (`ElectionId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `election`
--

INSERT INTO `election` (`ElectionId`, `ElectionName`, `ElectionTypeId`, `StreamId`, `ElectionStartDate`, `ElectionEndDate`, `AddUserId`, `AddDate`, `EditDate`, `IsActive`) VALUES
(18, '', 7, 34, '0000-00-00', '0000-00-00 00:00:00', 52, '2013-02-27 21:48:13', '0000-00-00 00:00:00', 1),
(14, 'Election 2013', 8, 34, '0000-00-00', '0000-00-00 00:00:00', 1, '2012-11-06 22:53:37', '0000-00-00 00:00:00', 1),
(12, 'Election 2013', 1, 34, '0000-00-00', '0000-00-00 00:00:00', 39, '2012-11-06 20:08:43', '0000-00-00 00:00:00', 1),
(11, 'Election 2013', 2, 34, '0000-00-00', '0000-00-00 00:00:00', 1, '2012-11-06 20:04:17', '0000-00-00 00:00:00', 1),
(16, 'Election 2014', 6, 34, '0000-00-00', '0000-00-00 00:00:00', 39, '2012-11-07 10:43:02', '0000-00-00 00:00:00', 1),
(17, 'SAIT', 6, 34, '2011-03-03', '0000-00-00 00:00:00', 39, '2012-11-07 11:25:37', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `election_participants`
--

CREATE TABLE IF NOT EXISTS `election_participants` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `electionyearid` int(11) NOT NULL,
  `ParticipantId` int(11) NOT NULL,
  `AddUserId` int(11) NOT NULL,
  `AddDate` datetime NOT NULL,
  `EditDate` datetime NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  `electiontypeid` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=90 ;

--
-- Dumping data for table `election_participants`
--

INSERT INTO `election_participants` (`Id`, `electionyearid`, `ParticipantId`, `AddUserId`, `AddDate`, `EditDate`, `IsActive`, `electiontypeid`) VALUES
(71, 6, 48, 52, '2013-03-04 14:30:02', '0000-00-00 00:00:00', 1, 9),
(5, 1, 42, 3, '2012-11-06 11:24:45', '0000-00-00 00:00:00', 1, 6),
(74, 1, 53, 39, '2013-03-07 20:31:28', '0000-00-00 00:00:00', 1, 7),
(73, 1, 44, 39, '2013-03-07 20:31:23', '0000-00-00 00:00:00', 1, 7),
(72, 5, 54, 54, '2013-03-04 15:15:31', '0000-00-00 00:00:00', 1, 8),
(70, 6, 42, 52, '2013-03-04 14:29:56', '0000-00-00 00:00:00', 1, 7),
(69, 6, 52, 52, '2013-03-04 14:29:49', '0000-00-00 00:00:00', 1, 7),
(66, 5, 42, 52, '2013-03-02 00:44:57', '0000-00-00 00:00:00', 1, 7),
(60, 5, 48, 39, '2013-03-01 21:39:30', '0000-00-00 00:00:00', 1, 7),
(68, 6, 53, 52, '2013-03-04 14:29:38', '0000-00-00 00:00:00', 1, 6),
(65, 5, 45, 52, '2013-03-01 23:09:17', '0000-00-00 00:00:00', 1, 6),
(89, 10, 57, 39, '2013-03-20 13:57:28', '0000-00-00 00:00:00', 1, 27),
(88, 10, 53, 39, '2013-03-20 13:57:07', '0000-00-00 00:00:00', 1, 27),
(87, 10, 44, 39, '2013-03-20 13:56:57', '0000-00-00 00:00:00', 1, 23),
(86, 10, 45, 39, '2013-03-20 13:56:44', '0000-00-00 00:00:00', 1, 23),
(85, 9, 42, 39, '2013-03-20 13:52:29', '0000-00-00 00:00:00', 1, 27),
(84, 9, 61, 39, '2013-03-20 13:52:20', '0000-00-00 00:00:00', 1, 10),
(83, 9, 52, 39, '2013-03-20 13:52:15', '0000-00-00 00:00:00', 1, 10),
(82, 9, 53, 39, '2013-03-20 13:52:07', '0000-00-00 00:00:00', 1, 7),
(81, 9, 44, 39, '2013-03-20 13:51:58', '0000-00-00 00:00:00', 1, 7),
(80, 1, 54, 39, '2013-03-08 13:13:44', '0000-00-00 00:00:00', 1, 7),
(79, 7, 45, 39, '2013-03-08 10:15:03', '0000-00-00 00:00:00', 1, 7),
(78, 7, 52, 39, '2013-03-08 10:14:58', '0000-00-00 00:00:00', 1, 7),
(77, 7, 44, 39, '2013-03-08 10:14:52', '0000-00-00 00:00:00', 1, 13),
(76, 7, 53, 39, '2013-03-08 10:14:46', '0000-00-00 00:00:00', 1, 13),
(75, 1, 52, 39, '2013-03-07 20:31:35', '0000-00-00 00:00:00', 1, 13),
(64, 5, 53, 52, '2013-03-01 23:09:09', '0000-00-00 00:00:00', 1, 6),
(58, 5, 52, 39, '2013-03-01 21:39:12', '0000-00-00 00:00:00', 1, 7),
(67, 6, 44, 52, '2013-03-04 14:29:25', '0000-00-00 00:00:00', 1, 6),
(49, 1, 45, 39, '2013-03-01 14:27:01', '0000-00-00 00:00:00', 1, 6);

-- --------------------------------------------------------

--
-- Table structure for table `election_type`
--

CREATE TABLE IF NOT EXISTS `election_type` (
  `ElectionTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `ElectionType` varchar(50) NOT NULL,
  `AddUserId` int(11) NOT NULL,
  `AddDate` datetime NOT NULL,
  `EditDate` datetime NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  `sequence` int(10) NOT NULL,
  PRIMARY KEY (`ElectionTypeId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `election_type`
--

INSERT INTO `election_type` (`ElectionTypeId`, `ElectionType`, `AddUserId`, `AddDate`, `EditDate`, `IsActive`, `sequence`) VALUES
(13, 'President', 0, '2013-03-07 19:41:42', '0000-00-00 00:00:00', 1, 1),
(23, 'Secretary', 0, '2013-03-07 20:01:25', '0000-00-00 00:00:00', 1, 3),
(7, 'Vice President', 0, '2012-11-06 22:49:29', '0000-00-00 00:00:00', 1, 2),
(10, 'Tresurer', 0, '2013-03-07 19:34:12', '0000-00-00 00:00:00', 1, 5),
(24, 'Joint Secretary', 0, '2013-03-07 20:02:41', '0000-00-00 00:00:00', 1, 4),
(25, 'Joint Treasurer', 0, '2013-03-07 20:03:03', '0000-00-00 00:00:00', 1, 6),
(27, 'Head', 0, '2013-03-20 13:50:31', '0000-00-00 00:00:00', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `election_votelist`
--

CREATE TABLE IF NOT EXISTS `election_votelist` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ParticipantId` int(11) NOT NULL,
  `VoteUserId` int(11) NOT NULL,
  `AddDate` datetime NOT NULL,
  `electionyearid` int(11) NOT NULL,
  `electiontypeid` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `election_votelist`
--

INSERT INTO `election_votelist` (`Id`, `ParticipantId`, `VoteUserId`, `AddDate`, `electionyearid`, `electiontypeid`) VALUES
(31, 44, 52, '2013-03-01 22:42:27', 5, 6),
(32, 53, 52, '2013-03-01 22:42:27', 5, 8),
(33, 48, 52, '2013-03-01 22:42:27', 5, 7),
(34, 54, 52, '2013-03-01 22:42:27', 5, 9),
(35, 48, 52, '2013-03-04 14:30:18', 6, 9),
(36, 42, 52, '2013-03-04 14:30:18', 6, 7),
(37, 53, 52, '2013-03-04 14:30:18', 6, 6),
(38, 42, 54, '2013-03-04 15:14:27', 5, 7),
(39, 45, 54, '2013-03-04 15:14:27', 5, 6),
(40, 42, 52, '2013-03-20 13:53:37', 9, 27),
(41, 61, 52, '2013-03-20 13:53:37', 9, 10),
(42, 53, 52, '2013-03-20 13:53:37', 9, 7),
(43, 57, 52, '2013-03-20 13:58:43', 10, 27);

-- --------------------------------------------------------

--
-- Table structure for table `election_year`
--

CREATE TABLE IF NOT EXISTS `election_year` (
  `electionyearid` int(11) NOT NULL AUTO_INCREMENT,
  `electionyearname` varchar(50) NOT NULL,
  `ElectionFor` varchar(3) NOT NULL,
  `streamid` int(11) NOT NULL,
  PRIMARY KEY (`electionyearid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `election_year`
--

INSERT INTO `election_year` (`electionyearid`, `electionyearname`, `ElectionFor`, `streamid`) VALUES
(1, '8IT-2013', '09', 34),
(5, '6IT-2013', '10', 34),
(7, '4IT-2013', '11', 34),
(8, '2IT-2013', '12', 34),
(9, 'New for 09dit', '09', 34),
(10, 'hiral joshi', '09', 34);

-- --------------------------------------------------------

--
-- Table structure for table `event_master`
--

CREATE TABLE IF NOT EXISTS `event_master` (
  `EventId` int(10) NOT NULL AUTO_INCREMENT,
  `StreamId` int(11) NOT NULL,
  `EventName` varchar(50) NOT NULL,
  `EventStartTime` datetime NOT NULL,
  `EventEndTime` datetime NOT NULL,
  `EventDescription` varchar(1000) NOT NULL,
  `AddDate` datetime NOT NULL,
  `EditDate` datetime NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  PRIMARY KEY (`EventId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `event_master`
--

INSERT INTO `event_master` (`EventId`, `StreamId`, `EventName`, `EventStartTime`, `EventEndTime`, `EventDescription`, `AddDate`, `EditDate`, `IsActive`) VALUES
(24, 34, 'RRRR', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '2013-03-20 13:35:32', '0000-00-00 00:00:00', 1),
(20, 34, 'Cricket 2013', '2012-11-08 00:00:00', '2012-11-17 00:00:00', '', '2012-11-07 06:23:55', '0000-00-00 00:00:00', 1),
(22, 34, 'Horizone-12', '2012-11-07 00:00:00', '2012-12-13 00:00:00', '', '2012-11-07 10:27:34', '0000-00-00 00:00:00', 1),
(23, 34, 'Horizon-13', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '2013-02-06 15:14:18', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `event_result`
--

CREATE TABLE IF NOT EXISTS `event_result` (
  `EventId` int(11) NOT NULL,
  `EventUserId` int(11) NOT NULL,
  `EventResult` varchar(30) NOT NULL,
  `AddDate` datetime NOT NULL,
  `EditDate` datetime NOT NULL,
  `IsActive` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event_result`
--


-- --------------------------------------------------------

--
-- Table structure for table `event_users`
--

CREATE TABLE IF NOT EXISTS `event_users` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `EventId` int(11) NOT NULL,
  `EventUserId` int(11) NOT NULL,
  `EventUserType` int(11) NOT NULL,
  `AddDate` datetime NOT NULL,
  `EditDate` datetime NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `event_users`
--

INSERT INTO `event_users` (`Id`, `EventId`, `EventUserId`, `EventUserType`, `AddDate`, `EditDate`, `IsActive`) VALUES
(9, 51, 45, 0, '2012-11-07 07:31:41', '0000-00-00 00:00:00', 1),
(8, 50, 45, 0, '2012-11-07 07:31:41', '0000-00-00 00:00:00', 1),
(6, 47, 45, 0, '2012-11-07 07:30:28', '0000-00-00 00:00:00', 1),
(7, 49, 45, 0, '2012-11-07 07:31:41', '0000-00-00 00:00:00', 1),
(30, 64, 44, 0, '2013-03-04 22:55:31', '0000-00-00 00:00:00', 1),
(11, 60, 45, 0, '2012-11-07 09:22:35', '0000-00-00 00:00:00', 1),
(12, 62, 45, 0, '2012-11-07 10:28:59', '0000-00-00 00:00:00', 1),
(13, 62, 53, 0, '2012-11-07 10:29:57', '0000-00-00 00:00:00', 1),
(14, 62, 44, 0, '2012-11-07 10:52:13', '0000-00-00 00:00:00', 1),
(15, 63, 44, 0, '2012-11-07 10:52:13', '0000-00-00 00:00:00', 1),
(16, 49, 52, 0, '2013-01-02 21:17:21', '0000-00-00 00:00:00', 1),
(17, 50, 52, 0, '2013-01-02 21:17:21', '0000-00-00 00:00:00', 1),
(18, 50, 39, 0, '2013-01-02 21:18:19', '0000-00-00 00:00:00', 1),
(19, 61, 39, 0, '2013-01-02 21:19:27', '0000-00-00 00:00:00', 1),
(20, 61, 52, 0, '2013-01-02 21:21:45', '0000-00-00 00:00:00', 1),
(21, 47, 52, 0, '2013-01-04 13:28:03', '0000-00-00 00:00:00', 1),
(22, 49, 54, 0, '2013-01-08 11:00:00', '0000-00-00 00:00:00', 1),
(23, 50, 54, 0, '2013-01-08 11:00:00', '0000-00-00 00:00:00', 1),
(24, 50, 55, 0, '2013-01-08 11:25:33', '0000-00-00 00:00:00', 1),
(25, 61, 55, 0, '2013-01-08 11:25:33', '0000-00-00 00:00:00', 1),
(26, 64, 52, 0, '2013-02-06 15:15:35', '0000-00-00 00:00:00', 1),
(27, 65, 52, 0, '2013-02-26 17:17:36', '0000-00-00 00:00:00', 1),
(28, 64, 54, 0, '2013-03-04 15:21:13', '0000-00-00 00:00:00', 1),
(29, 65, 54, 0, '2013-03-04 21:57:49', '0000-00-00 00:00:00', 1),
(31, 65, 44, 0, '2013-03-04 22:55:31', '0000-00-00 00:00:00', 1),
(32, 62, 52, 0, '2013-03-20 14:16:27', '0000-00-00 00:00:00', 1),
(33, 63, 52, 0, '2013-03-20 14:16:27', '0000-00-00 00:00:00', 1),
(34, 66, 52, 0, '2013-03-20 14:22:53', '0000-00-00 00:00:00', 1),
(35, 67, 52, 0, '2013-03-20 14:22:53', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `FeedBackId` int(11) NOT NULL AUTO_INCREMENT,
  `FeedBackTopic` varchar(200) NOT NULL,
  `FeedBackDescription` varchar(1000) NOT NULL,
  `Name` varchar(200) NOT NULL,
  `Address` varchar(250) NOT NULL,
  `City` varchar(20) NOT NULL,
  `State` varchar(20) NOT NULL,
  `Country` varchar(20) NOT NULL,
  `Zip` varchar(20) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `suggestion` varchar(2000) DEFAULT NULL,
  `Phone` varchar(13) NOT NULL,
  `AddDate` datetime NOT NULL,
  `EditDate` datetime NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  PRIMARY KEY (`FeedBackId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`FeedBackId`, `FeedBackTopic`, `FeedBackDescription`, `Name`, `Address`, `City`, `State`, `Country`, `Zip`, `Email`, `suggestion`, `Phone`, `AddDate`, `EditDate`, `IsActive`) VALUES
(42, '', '', 'Maulik', '2,RanchhodNagar Society', 'Rajkot', 'Gujarat', '', '', 'maulikpatel0095@gmail.com', 'As Student This Website Is Speechless..!!', '8511111195', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `forum_ans`
--

CREATE TABLE IF NOT EXISTS `forum_ans` (
  `question_id` int(4) NOT NULL,
  `a_id` int(4) NOT NULL,
  `a_name` varchar(65) NOT NULL,
  `a_email` varchar(65) NOT NULL,
  `a_ans` longtext NOT NULL,
  `a_datetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forum_ans`
--

INSERT INTO `forum_ans` (`question_id`, `a_id`, `a_name`, `a_email`, `a_ans`, `a_datetime`) VALUES
(58, 3, 'Devyani Prajapati', '', 'rujit\r\n', '2013-02-26 17:28:33'),
(60, 1, 'Maulik Sojitra', '', 'yes... u r ri8 ...', '2013-02-26 17:32:26'),
(61, 1, 'Devyani Prajapati', '', 'mast hatu..\r\n', '2013-03-20 13:40:08'),
(56, 4, 'Rujit Raval', '', 'Sorry', '2012-11-07 08:45:40'),
(58, 2, 'Devyani Prajapati', '', 'fsdfwfw', '2013-02-26 17:26:06'),
(58, 1, 'Darshan Nayak', '', 'hahaha', '2012-11-07 10:47:15');

-- --------------------------------------------------------

--
-- Table structure for table `forum_question`
--

CREATE TABLE IF NOT EXISTS `forum_question` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `topic` varchar(255) NOT NULL,
  `detail` longtext NOT NULL,
  `name` varchar(65) NOT NULL,
  `email` varchar(65) NOT NULL,
  `datetime` datetime DEFAULT NULL,
  `view` int(4) NOT NULL,
  `reply` int(4) NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=63 ;

--
-- Dumping data for table `forum_question`
--

INSERT INTO `forum_question` (`id`, `topic`, `detail`, `name`, `email`, `datetime`, `view`, `reply`, `IsActive`) VALUES
(62, 'DJ??', 'u want it ??', '09dit002', '', '2020-03-13 08:11:06', 0, 0, 1),
(61, 'What about Mohit Chauhan ??', 'How was that ?', 'temp', '', '2004-03-13 09:48:54', 5, 1, 1),
(60, 'fmweklfmweqkf', 'dwefdwfdw', 'temp', '', '2026-02-13 12:01:07', 7, 1, 1),
(57, 'Hello', 'Hello Everyone', '08dit201', '', '2006-11-12 11:33:01', 3, 0, 1),
(58, 'Hello', 'Happy Diwali', '09dit050', '', '2007-11-12 05:16:42', 22, 3, 1),
(59, 'What about your training ????', ',lasmdlknkln\r\nlsnljsnf\r\nmskfncksnfc\r\noinsf\r\nmklsnmks\r\nskvn sv m', '09dit002', '', '2018-01-13 09:48:17', 0, 0, 0),
(56, 'Are U Missing Nirma...????', 'Say Truly...!!!', '08dit201', '', '2006-11-12 10:13:16', 19, 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `home_desc`
--

CREATE TABLE IF NOT EXISTS `home_desc` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `AddDate` datetime NOT NULL,
  `EditDate` datetime NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `home_desc`
--

INSERT INTO `home_desc` (`ID`, `description`, `AddDate`, `EditDate`) VALUES
(7, '<p>\r\n	<span style="display: none;">&nbsp;</span></p>\r\n<h2 style="color: red;">\r\n	<span style="color:#999999;"><cite><span style="font-size:16px;"><span style="font-family:georgia,serif;"><span style="font-family:lucida sans unicode,lucida grande,sans-serif;">Institute of Diploma</span> Studies emphasizes the all round devlopment of its students. It aims at <strong>producing not only good professionals, but also good and worthy citizens of a great country, aiding in its overall progress and development.</strong></span></span></cite></span></h2>\r\n<p>\r\n	<strong><span style="color:#999999;"><cite><span style="font-size:16px;"><span style="font-family:georgia,serif;">It endeavours to treat every student as an individual, to recognize their potential and to ensure that they receive the best preparation and training for achieving their career ambitions and life goals.</span></span></cite></span></strong></p>\r\n<p>\r\n	<span style="display: none;">&nbsp;</span></p>\r\n', '2012-11-01 00:51:45', '2013-03-20 12:29:53');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `NewsId` int(11) NOT NULL AUTO_INCREMENT,
  `NewsSubject` varchar(1000) NOT NULL,
  `NewsDescription` varchar(8000) NOT NULL,
  `StreamId` int(11) NOT NULL,
  `AddUserId` int(11) NOT NULL,
  `AddDate` datetime NOT NULL,
  `EditDate` datetime NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  PRIMARY KEY (`NewsId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`NewsId`, `NewsSubject`, `NewsDescription`, `StreamId`, `AddUserId`, `AddDate`, `EditDate`, `IsActive`) VALUES
(14, 'CULFEST', '                                wdwdwd																																																', 34, 0, '2013-03-07 21:21:19', '0000-00-00 00:00:00', 1),
(15, 'scqsc', 'cwqccqwc														', 34, 0, '2013-03-07 21:22:00', '0000-00-00 00:00:00', 1),
(10, 'SAIT', '                                SAIT Student had organized a competition on Essay writing on 16th August, 2013.																', 1, 0, '2012-11-06 15:40:13', '0000-00-00 00:00:00', 0),
(13, 'ISTE', '                                                                ISTE Student Chapter-NIDS had organized a competition on Poster making on 9th August, 2013																											', 1, 0, '2012-11-07 09:06:42', '0000-00-00 00:00:00', 1),
(17, 'technical event', '                     we have organize tech. event on 1st may..           								', 37, 0, '2013-03-20 12:49:56', '0000-00-00 00:00:00', 1),
(18, 'fgfdfdf', '                          fgfgtf      								', 34, 0, '2013-03-20 13:33:28', '0000-00-00 00:00:00', 1),
(19, 'WELCOME 2 IC', '            Batch 12 is welcome.                    								', 42, 0, '2013-03-20 13:49:28', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

CREATE TABLE IF NOT EXISTS `newsletter` (
  `NewsletterId` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `StreamId` int(11) NOT NULL,
  `AddUserId` int(11) DEFAULT NULL,
  `AddDate` datetime DEFAULT NULL,
  `EditDate` datetime DEFAULT NULL,
  `IsActive` bit(1) DEFAULT NULL,
  `FileName` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`NewsletterId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `newsletter`
--

INSERT INTO `newsletter` (`NewsletterId`, `Name`, `StreamId`, `AddUserId`, `AddDate`, `EditDate`, `IsActive`, `FileName`) VALUES
(5, 'paper', 34, 39, '2013-03-04 20:57:59', NULL, b'1', '1CED04_SPE_Jan_09.pdf'),
(6, 'lees2', 37, 41, '2013-03-04 21:02:38', NULL, b'1', 'LEES NEWSLETTER.pdf'),
(8, 'meso', 38, 40, '2013-03-04 21:05:32', NULL, b'1', 'MESO NEWSLETTER.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `photo_gallery`
--

CREATE TABLE IF NOT EXISTS `photo_gallery` (
  `PhotoId` int(10) NOT NULL AUTO_INCREMENT,
  `AlbumId` int(11) NOT NULL,
  `PhotoName` varchar(200) NOT NULL,
  `AddUserId` int(11) NOT NULL,
  `AddDate` datetime NOT NULL,
  `EditDate` datetime NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  `extention` varchar(8) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`PhotoId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `photo_gallery`
--

INSERT INTO `photo_gallery` (`PhotoId`, `AlbumId`, `PhotoName`, `AddUserId`, `AddDate`, `EditDate`, `IsActive`, `extention`, `filename`) VALUES
(31, 8, '', 52, '2013-03-20 14:26:02', '0000-00-00 00:00:00', 1, '', '2012-08-06-148.jpg'),
(30, 8, '', 52, '2013-03-20 14:25:45', '0000-00-00 00:00:00', 1, '', '223.jpg'),
(29, 8, '', 52, '2013-03-20 14:25:31', '0000-00-00 00:00:00', 1, '', '218.jpg'),
(27, 1, '', 39, '2012-11-06 17:11:26', '0000-00-00 00:00:00', 1, '', '100_2482.jpg'),
(26, 1, '', 39, '2012-11-06 15:12:16', '0000-00-00 00:00:00', 1, '', '100_2415.jpg'),
(25, 1, '', 39, '2012-11-06 15:11:52', '0000-00-00 00:00:00', 1, '', '100_2406.jpg'),
(24, 1, '', 39, '2012-11-06 15:11:34', '0000-00-00 00:00:00', 1, '', '100_2403.jpg'),
(23, 1, '', 39, '2012-11-06 15:11:12', '0000-00-00 00:00:00', 1, '', '100_2396.jpg'),
(22, 1, '', 39, '2012-11-06 15:10:39', '0000-00-00 00:00:00', 1, '', '100_2371.jpg'),
(21, 1, '', 39, '2012-11-06 15:10:19', '0000-00-00 00:00:00', 1, '', '100_2352.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `stream`
--

CREATE TABLE IF NOT EXISTS `stream` (
  `StreamId` int(2) NOT NULL AUTO_INCREMENT,
  `StreamName` varchar(50) NOT NULL,
  `StreamDescription` varchar(1000) NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  `AddDate` datetime NOT NULL,
  `EditDate` datetime DEFAULT NULL,
  PRIMARY KEY (`StreamId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `stream`
--

INSERT INTO `stream` (`StreamId`, `StreamName`, `StreamDescription`, `IsActive`, `AddDate`, `EditDate`) VALUES
(40, 'CESA', 'The Computer Engineering Student Association (CESA) was initiated in 2002. This association is of the students, by the students, for the students to help them in their overall development as per Nirma Universityâ€™s mission Statement.								', 1, '2013-03-08 12:56:27', NULL),
(34, 'SAIT', 'Information Technology department started in year 2001. Department is focusing on quality education & all round development of the students. To update curriculum as per the industry requirement, department is constantly in touch with industry experts. Expert lectures, workshops and seminars are frequently arranged by the department which helps the students to enrich their knowledge about latest trends practices etc. Students are being rigorously counseled for their academic and overall excellence...\r\n \r\n																												', 1, '2012-11-06 14:24:23', NULL),
(41, 'Civil', 'bgvgvb							', 1, '2013-03-08 13:35:15', NULL),
(42, 'IC', '								', 1, '2013-03-20 13:47:13', NULL),
(36, 'ECON', 'The department, establishment in 2001, offers Diploma Programme in Electronics & Communication Engineering. \r\n								', 1, '2012-11-06 14:26:03', NULL),
(37, 'LEES', 'The department, established in 2003. The department has 3 years'' academic program offering Diploma in Electrical Engineering. The department is equipped with latest experimental & computational facilities and well qualified faculty base to cater the academic and other kinds of students'' needs to enforce mission and vision of the university. \r\n								', 1, '2012-11-06 14:26:25', NULL),
(38, 'MESO', 'The Mechanical Engineering department was established in the year 1997 to provide quality education to the students in the area of Mechanical Engineering and to cater the needs of industry. Department has well developed infrastructure for diploma program in Mechanical Engineering. The department has excellent laboratory facilities and workshops, well qualified and experienced staff in all the interdisciplinary areas of mechanical engineering. We create a conducive environment for teaching - learning process and our faculty members always strive hard for academic excellence and overall personality development of students.\r\n								', 1, '2012-11-06 14:26:49', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `stream_subadmin_relation`
--

CREATE TABLE IF NOT EXISTS `stream_subadmin_relation` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `StreamId` int(2) NOT NULL,
  `UserId` varchar(10) NOT NULL,
  `AddDate` datetime NOT NULL,
  `EditDate` datetime NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `stream_subadmin_relation`
--

INSERT INTO `stream_subadmin_relation` (`Id`, `StreamId`, `UserId`, `AddDate`, `EditDate`, `IsActive`) VALUES
(25, 34, '08dit005', '2012-11-06 15:04:04', '0000-00-00 00:00:00', 1),
(23, 35, '08dit201', '2012-11-06 15:02:18', '0000-00-00 00:00:00', 1),
(22, 34, '08dit020', '2012-11-06 14:59:25', '0000-00-00 00:00:00', 1),
(21, 34, 'anu', '2012-11-06 14:55:38', '0000-00-00 00:00:00', 1),
(20, 34, '08dit009', '2012-11-06 14:54:10', '0000-00-00 00:00:00', 1),
(19, 37, 'sub_lees', '2012-11-06 14:46:22', '0000-00-00 00:00:00', 1),
(13, 35, 'sub_cesa', '2012-11-06 14:34:56', '0000-00-00 00:00:00', 1),
(18, 38, 'sub_meso', '2012-11-06 14:45:12', '0000-00-00 00:00:00', 1),
(17, 34, 'sub_sait', '2012-11-06 14:44:09', '0000-00-00 00:00:00', 1),
(16, 36, 'sub_econ', '2012-11-06 14:40:22', '0000-00-00 00:00:00', 1),
(26, 34, '09dit045', '2012-11-06 15:06:56', '0000-00-00 00:00:00', 1),
(42, 42, 'sub_ic', '2013-03-20 13:48:30', '0000-00-00 00:00:00', 1),
(30, 34, '09dit002', '2012-11-07 09:14:07', '0000-00-00 00:00:00', 1),
(32, 34, 'temp', '2013-01-07 23:42:19', '0000-00-00 00:00:00', 1),
(33, 34, 'temp1', '2013-01-08 11:24:48', '0000-00-00 00:00:00', 1),
(34, 41, 'sub_civil', '2013-03-08 13:38:13', '0000-00-00 00:00:00', 1),
(35, 41, '08dci001', '2013-03-08 13:39:45', '0000-00-00 00:00:00', 1),
(41, 34, 'anu.up', '2013-03-20 12:46:25', '0000-00-00 00:00:00', 1),
(40, 34, 'user1', '2013-03-13 22:21:26', '0000-00-00 00:00:00', 1),
(39, 34, '09dit005', '2013-03-12 21:35:03', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `subevent_master`
--

CREATE TABLE IF NOT EXISTS `subevent_master` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `EventId` int(11) NOT NULL,
  `SubEventName` varchar(100) NOT NULL,
  `SubDesc` varchar(500) NOT NULL,
  `SEStart` datetime NOT NULL,
  `SEEnd` datetime NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  `AddUserId` varchar(10) NOT NULL,
  `AddDate` datetime NOT NULL,
  `EditDate` datetime NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=68 ;

--
-- Dumping data for table `subevent_master`
--

INSERT INTO `subevent_master` (`Id`, `EventId`, `SubEventName`, `SubDesc`, `SEStart`, `SEEnd`, `IsActive`, `AddUserId`, `AddDate`, `EditDate`) VALUES
(1, 1, 'rr', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '', '2012-11-03 09:15:25', '0000-00-00 00:00:00'),
(47, 10, 'Paper Presentation', 'Paper presentation for all students.																																								', '2012-11-07 00:00:00', '2012-11-15 00:00:00', 1, '', '2012-11-06 15:22:39', '0000-00-00 00:00:00'),
(49, 16, 'Robotics', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '', '2012-11-06 15:24:14', '0000-00-00 00:00:00'),
(50, 16, 'Lan Gaming', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '', '2012-11-06 15:24:28', '0000-00-00 00:00:00'),
(53, 0, 'Computer Quiz', 'Computer quiz for all students								', '2012-11-07 00:00:00', '2012-12-13 00:00:00', 1, '', '2012-11-07 00:28:32', '0000-00-00 00:00:00'),
(54, 0, 'Computer Quiz', 'Computer quiz for all students																', '2012-11-08 00:00:00', '2012-12-13 00:00:00', 1, '', '2012-11-07 00:28:51', '0000-00-00 00:00:00'),
(57, 0, 'rr', 'trtrwet			gffsdgfdgfdg																																													', '2012-11-07 00:00:00', '2012-12-13 00:00:00', 0, '', '2012-11-07 00:38:09', '0000-00-00 00:00:00'),
(60, 21, 'Singing', 'Single Singer,\r\nGroup of two																', '2012-11-07 00:00:00', '2012-12-13 00:00:00', 1, '', '2012-11-07 06:25:29', '0000-00-00 00:00:00'),
(61, 16, 'Card Making', '															', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '', '2012-11-07 09:20:42', '0000-00-00 00:00:00'),
(62, 22, 'Rodies', '2 participants in a team ...								', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '', '2012-11-07 10:28:21', '0000-00-00 00:00:00'),
(63, 22, '1 Minute Game', '2 per team...								', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '', '2012-11-07 10:50:13', '0000-00-00 00:00:00'),
(64, 23, 'Kailash Kher', '								', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '', '2013-02-06 15:14:48', '0000-00-00 00:00:00'),
(65, 23, 'DJ ', '								', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '', '2013-02-06 15:14:58', '0000-00-00 00:00:00'),
(66, 24, 'DJ ', '																', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '', '2013-03-20 13:35:50', '0000-00-00 00:00:00'),
(67, 24, 'KK', '								', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '', '2013-03-20 13:36:02', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `Id` int(4) NOT NULL AUTO_INCREMENT,
  `UserId` varchar(10) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `UserFirstName` varchar(20) DEFAULT NULL,
  `UserLastName` varchar(20) DEFAULT NULL,
  `Batch` varchar(3) NOT NULL,
  `ActivationDate` datetime NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  `CreateDate` datetime NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Phone` varchar(13) NOT NULL,
  `UserType` int(1) NOT NULL,
  `EditUserId` int(11) NOT NULL,
  `EditDate` datetime NOT NULL,
  `ActivationUserId` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `UserId` (`UserId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=65 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Id`, `UserId`, `Password`, `UserFirstName`, `UserLastName`, `Batch`, `ActivationDate`, `IsActive`, `CreateDate`, `Email`, `Phone`, `UserType`, `EditUserId`, `EditDate`, `ActivationUserId`) VALUES
(1, 'admin', 'rr', 'administrator', 'administrator', '0', '2012-10-06 11:55:29', 1, '0000-00-00 00:00:00', 'rr@gmail.com', '999111119as', 1, 33, '0000-00-00 00:00:00', 0),
(44, '08dit020', '08DIT020', 'Chirag', 'Prajapati', '09', '2012-11-06 14:59:25', 1, '0000-00-00 00:00:00', 'yamrajpandya@gmail.com', '9974956153', 4, 0, '0000-00-00 00:00:00', 0),
(40, 'sub_meso', 'sub_meso', 'Anand', 'Patel', '0', '2012-11-06 14:45:12', 1, '0000-00-00 00:00:00', 'anand.patel@nirmauni.ac.in', '9909939302', 2, 0, '0000-00-00 00:00:00', 0),
(41, 'sub_lees', 'sub_lees', 'Tejas', 'Gandhi', '0', '2012-11-06 14:46:22', 1, '0000-00-00 00:00:00', 'tejas.gandhi@nirmauni.ac.in', '8511111195', 2, 0, '0000-00-00 00:00:00', 0),
(42, '08dit009', '08DIT009', 'Maulik', 'Sojitra', '0', '2012-11-06 14:54:10', 1, '0000-00-00 00:00:00', '08dit009@nirmauni.ac.in', '9375555550', 4, 0, '0000-00-00 00:00:00', 0),
(43, 'anu', 'ANU', 'Ajay', 'Upadhyaya', '0', '2012-11-06 14:55:38', 0, '0000-00-00 00:00:00', 'ajay.upadhyaya@nirmauni.ac.in', '9733442211', 3, 0, '0000-00-00 00:00:00', 0),
(38, 'sub_econ', 'sub_econ', 'Amit', 'Raval', '0', '2012-11-06 14:40:22', 1, '0000-00-00 00:00:00', 'amit.c.raval@nirmauni.ac.in', '9724507005', 2, 0, '0000-00-00 00:00:00', 0),
(35, 'sub_cesa', 'sub_cesa', 'Ajay', 'Patel', '0', '2012-11-06 14:34:56', 1, '0000-00-00 00:00:00', 'ajaypatel@nirmauni.ac.in', '9974956153', 2, 0, '0000-00-00 00:00:00', 0),
(39, 'sub_sait', 'sub_sait', 'Jashvant', 'Dave', '0', '2012-11-06 14:44:09', 1, '0000-00-00 00:00:00', 'jashvant.dave@nirmauni.ac.in', '9998994950', 2, 0, '0000-00-00 00:00:00', 0),
(45, '08dit201', '08DIT201', 'Rujit', 'Raval', '09', '2012-11-06 15:02:18', 1, '0000-00-00 00:00:00', '08dit201@nirmauni.ac.in', '9724507005', 4, 0, '0000-00-00 00:00:00', 0),
(52, '09dit002', '09DIT002', 'Devyani', 'Prajapati', '09', '2012-11-07 09:14:07', 1, '0000-00-00 00:00:00', '09dit002@nirmauni.ac.in', '9909909999', 4, 0, '0000-00-00 00:00:00', 0),
(53, '09dit050', '11111', 'Darshan', 'Nayak', '0', '2012-11-07 09:18:30', 1, '0000-00-00 00:00:00', '09dit050@nirmauni.ac.in', '9099013913', 4, 0, '0000-00-00 00:00:00', 0),
(48, '09dit045', '09DIT045', 'Vijay', 'Gajera', '0', '2012-11-06 15:06:56', 1, '0000-00-00 00:00:00', '09dit045@nirmauni.ac.in', '9099150556', 4, 0, '0000-00-00 00:00:00', 0),
(54, 'temp', 'temp', 'TEMP', 'TEMP', '12', '2013-01-07 23:42:19', 1, '0000-00-00 00:00:00', 'TEMP', '76767676767', 4, 0, '0000-00-00 00:00:00', 0),
(55, 'temp1', 'temp1', 'temp1', 'temp1', '0', '2013-01-08 11:24:48', 1, '0000-00-00 00:00:00', 'rrojf@gmail.com', '9879799797', 3, 0, '0000-00-00 00:00:00', 0),
(63, 'anu.up', 'anu.up', 'Ajay', 'Upadhyaya', '', '2013-03-20 12:46:25', 1, '0000-00-00 00:00:00', '123', '9428625801', 2, 0, '0000-00-00 00:00:00', 0),
(57, '08dci001', '08dci001', 'rutva', 'thumar', '0', '2013-03-08 13:39:45', 1, '0000-00-00 00:00:00', '08dci001@nirmauni.ac.in', '6847634923', 4, 0, '0000-00-00 00:00:00', 0),
(61, '09dit005', 'wxd', 'Hiral', 'Joshi', '0', '2013-03-12 21:35:03', 1, '0000-00-00 00:00:00', '09dit005@nirmauni.ac.in', '232323', 4, 0, '0000-00-00 00:00:00', 0),
(62, 'user1', 'user1', 'user1', 'user1', '09', '2013-03-13 22:21:26', 1, '0000-00-00 00:00:00', 'user1@f.com', '1234567', 4, 0, '0000-00-00 00:00:00', 0),
(64, 'sub_ic', 'sub_ic', 'a`', 'a', '', '2013-03-20 13:48:30', 1, '0000-00-00 00:00:00', 'a', '1', 2, 0, '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_detail`
--

CREATE TABLE IF NOT EXISTS `user_detail` (
  `UserId` int(11) NOT NULL,
  `FirstName` varchar(20) NOT NULL,
  `LastName` varchar(20) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `City` varchar(20) NOT NULL,
  `State` varchar(20) NOT NULL,
  `Zip` varchar(10) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Phone` varchar(13) NOT NULL,
  `JoinDate` datetime NOT NULL,
  `StreamId` int(11) NOT NULL,
  `Desgnation` varchar(20) NOT NULL,
  `AddDate` datetime NOT NULL,
  `EditDate` datetime NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  `photo` blob NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_detail`
--

